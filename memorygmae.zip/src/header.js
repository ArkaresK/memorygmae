import React from 'react';
import './header.css'

export default class View extends React.Component {
    render() {
        return (
            <div className="app">
                <header className="header">
                    <div className="title">Memory Game</div>
                </header> 
                             
            </div>);
    }
  }